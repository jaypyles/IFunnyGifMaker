# IFunnyGifMaker

This is a simple implementation to create captioned gifs, like those that appear on IFunny. The purpose of this was to implement into my own Discord server.

# To-Do

- [ ] Implement a faster way to compile the gifs
- [ ] Refactor the font size calculator

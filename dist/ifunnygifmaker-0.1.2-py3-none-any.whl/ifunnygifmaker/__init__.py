from ifunnygifmaker.mememaker import *
